import { Component, OnInit, AfterViewInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { ICardDetail, IFilterCard } from 'src/app/models/card-models';
import { ApiDataService } from 'src/app/services/api-data.service';
import { PopoverController, ModalController, ToastController, IonInput, IonInfiniteScrollContent, IonInfiniteScroll } from '@ionic/angular';
import { StudentMenuPopoverComponent } from 'src/app/components/popovers/student-menu-popover/student-menu-popover.component';
import { studentMenuPopOverID, radioPopOverID, addStudentModalID, viewStudentModalID } from 'src/app/models/components-id';
import { MatButtonToggleChange } from '@angular/material/button-toggle';
import { IRadioPopover } from 'src/app/models/shadow-component-models';
import { RadioPopoverComponent } from 'src/app/components/popovers/radio-popover/radio-popover.component';
import { AddStudentComponent } from 'src/app/components/modals/add/add-student/add-student.component';
import { ViewStudentComponent } from 'src/app/components/modals/view/view-student/view-student.component';
import { StudentService } from 'src/app/services/student.service';
import { CHECK_INTERNET_CON } from 'src/app/components/login/login.component';
import { ClassCourseService } from 'src/app/services/class-course.service';

@Component({
  selector: 'app-students',
  templateUrl: './students.page.html',
  styleUrls: ['./students.page.scss'],
})
export class StudentsPage implements OnInit, AfterViewInit {

  public cards: ICardDetail[] = [];
  public filterCards: ICardDetail[] = [];
  public searchMode: boolean = false;
  public sortMode: boolean = false;
  public searchString: string = '';
  public lastSearchString: string = '';
  public studentsStatus: 'active' | 'all' = 'active';
  public filterData: IFilterCard[] = [];
  public inputFirstLoad: boolean = true;
  public showError = false;
  public isLoading = true;
  public errMessage = "";
  public pageNum = 1;
  // public updateType = "1";
  // Flag to check if data from server in exhausted, for disabling ion infinite scroll
  public noMoreStudents = false;
  public noOfStudents: number;

  @ViewChild('scroll') scroll: IonInfiniteScroll; 

  public nameFilterData: IFilterCard[] = [
    {
      filterTitle: "A",
      filterData: this.getCards(),
    },
    {
      filterTitle: "L",
      filterData: this.getCards(),
    },
    {
      filterTitle: "M",
      filterData: this.getCards(),
    },
  ]

  public courseFilterData: IFilterCard[] = [
    {
      filterTitle: "Physics",
      filterData: this.getCards(),
    },
    {
      filterTitle: "English",
      filterData: this.getCards(),
    },
    {
      filterTitle: "Biology",
      filterData: this.getCards(),
    },
  ]

  public classFilterData: IFilterCard[] = [
    {
      filterTitle: "JS2A",
      filterData: this.getCards(),
    },
    {
      filterTitle: "SS2A",
      filterData: this.getCards(),
    },
    {
      filterTitle: "SS3B",
      filterData: this.getCards(),
    },
  ]

  public recentFilterData: IFilterCard[] = [
    {
      filterTitle: "1 year ago",
      filterData: this.getCards(),
    },
  ]


  constructor(
    private apiData: ApiDataService,
    private studentService: StudentService,
    private classService: ClassCourseService,
    private popoverCtrl: PopoverController,
    private modalCtrl: ModalController,
    private toastCtrl: ToastController,
  ) { 
  }

  ngOnInit() {
    //this.getCards();
  }

  ionViewDidEnter() {
    this.init();
  }

  ngAfterViewInit() {
  }

  async init() {
    await this.getStudents();
  }

  getCards() {
    //  this.cards = this.apiData.getStudentCards();
    return null; //this.cards;
  }

  toggleBtnClick(e: MatButtonToggleChange) {
    if(this.searchMode) return;
    this.displaySortData(e.value);
  }

  displaySortData(value: string) {
    this.filterData = [];
    if(value == 'name') {
      this.filterData = this.nameFilterData;
    }
    else if(value == 'course') {
      this.filterData = this.courseFilterData;
    }
    else if(value == 'class') {
      this.filterData = this.classFilterData;
    }
    else if(value == 'recent') {
      this.filterData = this.recentFilterData;
    }
  }

  enterSearchMode() {
    this.sortMode = false;
    this.searchMode = true;
    this.toggleSearchInput();
  }

  exitSearchMode() {
    this.sortMode = false;
    this.searchMode = false;
    this.errMessage = "";
    this.showError = false;
    this.pageNum = 1;
  }

  enterSortMode() {
    if(this.searchMode) return;

    this.sortMode = !this.sortMode;

    if(this.sortMode) {
      this.filterData = this.nameFilterData;
    }
    else {
      this.filterData = [];
    }
  }

  async showMenu(e) {
    const options: IRadioPopover[] = [
      {
        text: 'Active',
        value: 'active',
      },
      {
        text: 'All',
        value: 'all',
      },
    ]
    const popover = await this.popoverCtrl.create({
      component: RadioPopoverComponent,
      id: radioPopOverID,
      event: e,
      componentProps: {
        'value': this.studentsStatus,
        options
      }
    });

    await popover.present();
    const { data } = await popover.onWillDismiss();
    if(data == 'all' || data == 'active') {
      this.studentsStatus = data;

      this.isLoading = true;
      this.cards = [];
      this.getStudents();
    }
  }

  async refresh(e?) {
    if(this.isLoading) return;
    
    this.isLoading = true;
    this.pageNum = 1;
    if(this.searchMode) {
      this.filterCards = [];
      this.search();
    }
    else {
      this.cards = [];
      await this.getStudents();
    }
    e?.target.complete()
  }

  async loadData(e) {
    this.pageNum++;
    if(this.searchMode){
      this.searchRemote(this.searchString.trim());
    }
    else {
      await this.getStudents();
    }
    if(this.noMoreStudents) {
      e.target.disabled = true;
    }
    else {
      e.target.complete();
    }

  }

  async getStudents() {
    const updateType = this.studentsStatus == "active" ? "1" : "10";
    this.studentService.viewStudent({
      updateType,
      pageSize: "20",
      pageNum: this.pageNum.toString(),
    })
    .subscribe(async (res) => {
      if(res.statuscode == 200){
        res.dataResponse.forEach(async (student) => {
          this.cards.push({
            showImage: true,
            altImage: "icon",
            cardData: student,
            imageSrc: student.dpUrl,
            details: {
              "Name": student.fullName,
              "Class": "",
              "Courses Offering": "",
            }
          });
        });

        this.noOfStudents = res.dataResponse[0].totalRows;
        this.cards.forEach(async card => {
          card.details = {
            "Name": card.cardData.fullName,
            "Class": (await this.getClass(card.cardData.studentId))?.subClassName,
            "Subjects Offering": (await this.getCourse(card.cardData.studentId))[0]?.totalRows
          }
        });
      }
      else if(res.statuscode == 204){
        if(this.pageNum == 1){
          this.errMessage = "No students";
          this.showError = true;
        }
        else{
          this.noMoreStudents = true;
        }
      }
      else if(res.statuscode == 401) {
        this.errMessage = "Unauthorised";
        this.showError = true;
      }
      else {
        this.presentToast(res.status);
      }

      this.isLoading = false;

    }, (err) => {
      this.isLoading = false;

      this.presentToast(CHECK_INTERNET_CON);
    })
  }

  search() {
    if(this.searchString.trim() == "") {
      this.lastSearchString = this.searchString;
      this.filterCards = [];
      return;
    }

    // this.filterCards = this.cards.filter(card => {
    //   const details = Object.values(card.details);
    //   return details.some(detail => {
    //     let regEx = new RegExp(this.searchString, 'gi');
    //     let result = regEx.test(detail);
    //     return result;
    //   });
    // });
    this.pageNum = 1;
    this.filterCards = [];
    this.scroll.disabled = false;
    this.searchRemote(this.searchString.trim());
    this.lastSearchString = this.searchString.trim();
  }

  async searchRemote(searchString: string) {
    this.isLoading = true;
    const updateType = this.studentsStatus == "active" ? "3" : "12";
    this.studentService.viewStudent({
      updateType,
      pageSize: "10",
      pageNum: this.pageNum.toString(),
      qString: searchString,
    })
      .subscribe(res => {
        if (res.statuscode == 200) {
          res.dataResponse.forEach(student => {
            this.filterCards.push({
              showImage: true,
              altImage: "icon",
              cardData: student,
              imageSrc: student.dpUrl,
              details: {
                "Name": student.fullName.trim(),
                "Class": "Nil",
                "Subjects Offering": "Nil"
              }
            });
          });
          this.showError = false;

          this.filterCards.forEach(async card => {
            card.details = {
              "Name": card.cardData.fullName,
              "Class": (await this.getClass(card.cardData.studentId))?.subClassName,
              "Subjects Offering": (await this.getCourse(card.cardData.studentId))[0]?.totalRows
            }
          });
        }
        else if (res.statuscode == 204) {
          if (this.pageNum == 1) {
            this.errMessage = "Oops, no result ☹😝";
            this.showError = true;
            this.filterCards = [];
          }
          else {
            this.noMoreStudents = true;
          }
        }
        else if (res.statuscode == 401) {
          this.errMessage = "Unauthorised";
          this.showError = true;
        }
        else {
          this.presentToast(res.status);
        }

        this.isLoading = false;

      }, (err) => {
        this.isLoading = false;

        this.presentToast(CHECK_INTERNET_CON);
      }) 
  }

  async getClass(studentId: string): Promise<any> {
    const value = await this.classService.viewSubClass({
      updateType: "5",
      pageSize: "1",
      pageNum: "1",
      qString: studentId,
    }).toPromise()
    .then(async (res) => {
      if(res.statuscode == 200) {
        const response = res.dataResponse;
        return response[0];
      }
      else {
        return null;
      }
    }, err => {
      return null;
    });

    return value;
  }

  async getCourse(studentId: string): Promise<any> {
    const value = await this.classService.viewCourse({
      updateType: "5",
      pageSize: "20",
      pageNum: "1",
      qString: studentId,
    }).toPromise()
    .then(async (res) => {
      if(res.statuscode == 200) {
        const response = res.dataResponse;
        return response;
      }
      else {
        return [{}];
      }
    }, err => {
      return [{}];
    });

    return value;
  }

  async view(e) {
    const modal = await this.modalCtrl.create({
      component: ViewStudentComponent,
      id: viewStudentModalID,
      componentProps: {
        "studentId": e.cardData.studentId,
        "active": this.studentsStatus
      }
    });

    await modal.present();
    await modal.onWillDismiss()
    this.refresh();
  }

  async add() {
    const modal = await this.modalCtrl.create({
      component: AddStudentComponent,
      id: addStudentModalID,
    });

    await modal.present();
  }

  toggleSearchInput() {
    if(this.inputFirstLoad == true) {
      this.inputFirstLoad = false;
    }
  }

  ionViewWillEnter() {
    this.inputFirstLoad = true;
  }

  async presentToast(message: string) {
    const toast = await this.toastCtrl.create({
      message,
      position: "bottom",
      duration: 3000
    });

    return await toast.present();
  }

}

