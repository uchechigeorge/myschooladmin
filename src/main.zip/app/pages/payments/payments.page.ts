import { Component, OnInit } from '@angular/core';
import { MatButtonToggleChange } from '@angular/material/button-toggle';
import { PopoverController, ModalController } from '@ionic/angular';

import { ICardDetail, IFilterCard } from 'src/app/models/card-models';
import { ViewPaymentsComponent } from 'src/app/components/modals/view/view-payments/view-payments.component';
import { viewPaymentsModalID, classPaymentModalID, viewStudentPaymentModalID, viewSpecificPaymentModalID, searchSpecificPaymentModalID } from 'src/app/models/components-id';
import { ViewStudentPaymentComponent } from 'src/app/components/modals/view/view-student-payment/view-student-payment.component';
import { ViewSpecificFeesComponent } from 'src/app/components/modals/view/view-specific-fees/view-specific-fees.component';
import { SearchSpecificFeesComponent } from 'src/app/components/modals/view/search-specific-fees/search-specific-fees.component';
import { asyncTimeOut } from 'src/app/models/storage-model';

@Component({
  selector: 'app-payments',
  templateUrl: './payments.page.html',
  styleUrls: ['./payments.page.scss'],
})
export class PaymentsPage implements OnInit {

  public cards: ICardDetail[] = [];
  public filterCards: ICardDetail[] = [];
  public searchMode: boolean = false;
  // public sortMode: boolean = false;
  public searchString: string = '';
  public lastSearchString: string = '';
  public classCategory: 'class' | 'sub-class' = 'class';
  public filterData: IFilterCard[] = [];
  public inputFirstLoad: boolean = true;

  public showError = false;
  public isLoading = true;
  public errMessage = "";
  public pageNum = 1;
  // public updateType = "1";
  // Flag to check if data from server in exhausted, for disabling ion infinite scroll
  public noMorePayments = false;
  public noOfPayments: number;

  constructor(
    private modalCtrl: ModalController,
    private popoverCtrl: PopoverController,
  ) { }

  ngOnInit() {
  }

  ionViewDidEnter() {
    this.getPayment();
  }

  async getPayment() {
    this.isLoading = true;
    await asyncTimeOut(3000)
    
    this.cards = [];
    this.errMessage = "No payments";
    this.showError = true;
    this.isLoading = false;
  }

  toggleBtnClick(e: MatButtonToggleChange) {
    if(this.searchMode) return;
  }

  enterSearchMode() {
    this.searchMode = true;
    this.toggleSearchInput();
  }

  exitSearchMode() {
    this.searchMode = false;
  }


  search() {
    if((this.searchString.trim() == "" && this.lastSearchString.trim() == "") || this.lastSearchString.trim() == this.searchString.trim()) {
      this.filterCards = [];
    };

    if(this.searchString.trim() == "" || this.cards == null || this.cards.length == 0) {
      this.lastSearchString = this.searchString;
      return;
    }

    this.filterCards = this.cards.filter(card => {
      const details = Object.values(card.details);
      return details.some(detail => {
        let regEx = new RegExp(this.searchString.trim(), 'gi');
        let result = regEx.test(detail);
        return result;
      });
    });

    this.lastSearchString = this.searchString.trim();
  }

  searchRemote() {
    
  }

  async refresh(e?) {
    if(this.isLoading) {
      e?.target.complete()
      return;
    };

    this.isLoading = true;
    this.pageNum = 1;

    if(this.searchMode) {
      this.filterCards = [];
      this.search();
    }
    else {
      this.cards = [];
      await this.getPayment();
    }
    e?.target.complete()
  }

  async loadData(e) {
    this.pageNum++;
    if(this.searchMode){
      // await this.searchRemote(this.searchString.trim());
    }
    else {
      await this.getPayment();
    }

    if(this.noMorePayments) {
      e.target.disabled = true;
    }
    else {
      e.target.complete();
    }

  }


  toggleSearchInput() {
    if(this.inputFirstLoad == true) {
      this.inputFirstLoad = false;
    }
  }

  async view() {
    const modal = await this.modalCtrl.create({
      component: ViewStudentPaymentComponent,
      id: viewStudentPaymentModalID,
    });

    return await modal.present();
  }

  async editGeneralFees() {
    const modal = await this.modalCtrl.create({
      component: ViewPaymentsComponent,
      id: viewPaymentsModalID,
    });

    return await modal.present();
  }

  async editSpecificFees() {
    const modal = await this.modalCtrl.create({
      component: SearchSpecificFeesComponent,
      id: searchSpecificPaymentModalID,
    });

    return await modal.present();
  }

  ionViewWillEnter() {
    this.inputFirstLoad = true;
  }
}

