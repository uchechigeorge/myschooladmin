import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WebcamModule } from "ngx-webcam";

import { LoginComponent } from './login/login.component';
import { MaterialModule } from '../helpers/material.module';
import { LoginTitleComponent } from './svgs/login-title/login-title.component';
import { LoginLogoComponent } from './svgs/login-logo/login-logo.component';
import { DetailCardComponent } from './detail-card/detail-card.component';
import { HomeCardComponent } from './home-card/home-card.component';
import { ExpansionCardsComponent } from './expansion-cards/expansion-cards.component';
import { StudentMenuPopoverComponent } from './popovers/student-menu-popover/student-menu-popover.component';
import { RadioPopoverComponent } from './popovers/radio-popover/radio-popover.component';
import { AddClassComponent } from './modals/add/add-class/add-class.component';
import { AddCourseComponent } from './modals/add/add-course/add-course.component';
import { AddStudentComponent } from './modals/add/add-student/add-student.component';
import { AddTeacherComponent } from './modals/add/add-teacher/add-teacher.component';
import { ViewStudentComponent } from './modals/view/view-student/view-student.component';
import { ViewTeacherComponent } from './modals/view/view-teacher/view-teacher.component';
import { ViewClassComponent } from './modals/view/view-class/view-class.component';
import { ViewCourseComponent } from './modals/view/view-course/view-course.component';
import { ModalHeaderComponent } from './modals/modal-header/modal-header.component';
import { ProfilePictureComponent } from './modals/profile-picture/profile-picture.component';
import { EditDetailsInputComponent } from './edit-details-input/edit-details-input.component';
import { ViewProfilePicComponent } from './view-profile-pic/view-profile-pic.component';
import { ViewSubClassComponent } from './modals/view/view-sub-class/view-sub-class.component';
import { ViewPaymentsComponent } from './modals/view/view-payments/view-payments.component';
import { SharedDirectivesModule } from '../directives/shared-directives.module';
import { ResetPasswordComponent } from './modals/reset-password/reset-password.component';
import { ManageAdminsComponent } from './modals/manage-admins/manage-admins.component';
import { SetAdminRolesComponent } from './modals/set-admin-roles/set-admin-roles.component';
import { DesktopCamComponent } from './desktop-cam/desktop-cam.component';
import { DeskShotComponent } from './modals/desk-shot/desk-shot.component';
import { AddSessionComponent } from './modals/add/add-session/add-session.component';
import { AddTermComponent } from './modals/add/add-term/add-term.component';
import { ViewSessionComponent } from './modals/view/view-session/view-session.component';
import { ViewTermComponent } from './modals/view/view-term/view-term.component';
import { AddPaymentComponent } from './modals/add/add-payment/add-payment.component';
import { ViewStudentPaymentComponent } from './modals/view/view-student-payment/view-student-payment.component';
import { AddStudentPaymentComponent } from './modals/add/add-student-payment/add-student-payment.component';
import { ViewSpecificFeesComponent } from './modals/view/view-specific-fees/view-specific-fees.component';
import { SearchSpecificFeesComponent } from './modals/view/search-specific-fees/search-specific-fees.component';
import { EditGeneralFeesComponent } from './modals/view/edit-general-fees/edit-general-fees.component';
import { EditSpecificFeesComponent } from './modals/view/edit-specific-fees/edit-specific-fees.component';


@NgModule({
  declarations: [
    LoginComponent,
    LoginTitleComponent,
    LoginLogoComponent,
    DetailCardComponent,
    HomeCardComponent,
    ExpansionCardsComponent,
    StudentMenuPopoverComponent,
    RadioPopoverComponent,
    AddClassComponent,
    AddCourseComponent,
    AddStudentComponent,
    AddTeacherComponent,
    ViewStudentComponent,
    ViewTeacherComponent,
    ViewClassComponent,
    ViewSubClassComponent,
    ViewCourseComponent,
    ModalHeaderComponent,
    ProfilePictureComponent,
    EditDetailsInputComponent,
    ViewProfilePicComponent,
    // ClassPaymentComponent,
    // SubClassPaymentComponent,
    // StudentPaymentComponent,
    ResetPasswordComponent,
    ManageAdminsComponent,
    SetAdminRolesComponent,
    DesktopCamComponent,
    DeskShotComponent,
    AddSessionComponent,
    AddTermComponent,
    ViewTermComponent,
    ViewSessionComponent,
    
    AddPaymentComponent,
    AddStudentPaymentComponent,
    ViewPaymentsComponent,
    ViewStudentPaymentComponent,
    ViewSpecificFeesComponent,
    SearchSpecificFeesComponent,
    ViewSpecificFeesComponent,
    EditGeneralFeesComponent,
    EditSpecificFeesComponent
  ],
  exports: [
    LoginComponent,
    LoginTitleComponent,
    LoginLogoComponent,
    DetailCardComponent,
    HomeCardComponent,
    ExpansionCardsComponent,
    StudentMenuPopoverComponent,
    RadioPopoverComponent,
    AddClassComponent,
    AddCourseComponent,
    AddStudentComponent,
    AddTeacherComponent,
    ViewStudentComponent,
    ViewTeacherComponent,
    ViewClassComponent,
    ViewSubClassComponent,
    ViewCourseComponent,
    ModalHeaderComponent,
    ProfilePictureComponent,
    EditDetailsInputComponent,
    ViewProfilePicComponent,
    // ClassPaymentComponent,
    // SubClassPaymentComponent,
    // StudentPaymentComponent,
    ResetPasswordComponent,
    ManageAdminsComponent,
    SetAdminRolesComponent,
    DesktopCamComponent,
    DeskShotComponent,
    AddSessionComponent,
    AddTermComponent,
    ViewTermComponent,
    ViewSessionComponent,
    
    AddPaymentComponent,
    AddStudentPaymentComponent,
    ViewPaymentsComponent,
    ViewStudentPaymentComponent,
    ViewSpecificFeesComponent,
    SearchSpecificFeesComponent,
    ViewSpecificFeesComponent,
    EditGeneralFeesComponent,
    EditSpecificFeesComponent,
  ],
  imports: [
    CommonModule,
    IonicModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedDirectivesModule,
    WebcamModule,
  ]
})
export class ComponentsModule { }
