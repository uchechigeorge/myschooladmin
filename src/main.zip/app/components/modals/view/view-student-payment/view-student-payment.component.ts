import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { ViewStudentComponent } from '../view-student/view-student.component';
import { viewStudentModalID, viewStudentPaymentModalID } from 'src/app/models/components-id';

@Component({
  selector: 'app-view-student-payment',
  templateUrl: './view-student-payment.component.html',
  styleUrls: ['./view-student-payment.component.scss'],
})
export class ViewStudentPaymentComponent implements OnInit {
  public Name: string = 'Ade Moses';
  public StudentClass: string = 'SS 2A';
  public TimeOfPayment: string = '17th November, 2024';
  public TimeOfPaymentUTC: string = '17th November, 2024 (UTC + 1:00) West Central Africa';
  public Amount: string = '';
  public Session: '2024/2025';
  public showUserDate: boolean = true;
  public Term: number = 1;

  constructor(
    private modalCtrl: ModalController,
  ) { }

  ngOnInit() {}

  async viewStudent() {
    const modal = await this.modalCtrl.create({
      component: ViewStudentComponent,
      id: viewStudentModalID,
    });

    return await modal.present();
  }

  getPosition(value: number): string {
    if(value % 10 == 1) {
      return 'st';
    }
    else if(value % 10 == 2) {
      return 'nd';
    }
    else if(value % 10 == 3) {
      return 'rd';
    }
    else {
      return 'th';
    }
  }


  dismissModal() {
    this.modalCtrl.dismiss('', '', viewStudentPaymentModalID)
  }
}
