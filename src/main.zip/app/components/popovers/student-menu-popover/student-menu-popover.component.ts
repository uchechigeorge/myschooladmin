import { Component, OnInit, Input } from '@angular/core';
import { PopoverController } from '@ionic/angular';
import { studentMenuPopOverID } from 'src/app/models/components-id';

@Component({
  selector: 'app-student-menu-popover',
  templateUrl: './student-menu-popover.component.html',
  styleUrls: ['./student-menu-popover.component.scss'],
})
export class StudentMenuPopoverComponent implements OnInit {

  @Input('value') value: '';
  public option: string = '';

  constructor(
    private popOverCtrl: PopoverController,
  ) { }

  ngOnInit() {}

  dismissPopover(data: string) {
    this.popOverCtrl.dismiss(data, '', studentMenuPopOverID);
  }

  setValue(e) {
    const option = e.target.value;
    this.dismissPopover(option);
  }
}
