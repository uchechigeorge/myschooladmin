import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-logo',
  templateUrl: './login-logo.component.html',
  styleUrls: ['./login-logo.component.scss'],
})
export class LoginLogoComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
