import { HideHeaderDirective } from './hide-header.directive';

describe('HideHeaderDirective', () => {
  it('should create an instance', () => {
    const directive = new HideHeaderDirective();
    expect(directive).toBeTruthy();
  });
});
