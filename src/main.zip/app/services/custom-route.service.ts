import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

import { PageRoute, homeRoute, settingsRoute, teachersRoute, coursesRoute, classesRoute, paymentsRoute, loginRoute, studentsRoute, termsRoute } from '../models/app-routes';

@Injectable({
  providedIn: 'root'
})
export class CustomRouteService {

  public PageRoute: PageRoute;

  public PageUrl: string;

  constructor(
    private router: Router,
  ) {
    this.router.events.subscribe((val: NavigationEnd) => {
      if(!(val instanceof NavigationEnd)) return;

      this.PageRoute = this.convertStringToPageType(val.url);
      this.PageUrl = val.url;
    });
  }
  
  async getRoute() {
    return this.PageUrl;
  }

  convertStringToPageType(route: string): PageRoute {
    route = route.replace('/', '');
    switch(route) {
      case '':
        return PageRoute.Login;
      case homeRoute:
        return PageRoute.Home;
      case settingsRoute:
        return PageRoute.Settings;
      case teachersRoute:
        return PageRoute.Teachers;
      case studentsRoute:
        return PageRoute.Students;
      case coursesRoute:
        return PageRoute.Courses;
      case classesRoute:
        return PageRoute.Classes;
      case paymentsRoute:
        return PageRoute.Payments;
      case termsRoute:
        return PageRoute.Terms;
      case loginRoute:
        return PageRoute.Login;
      default:
        return PageRoute.None;
    }
  }

}