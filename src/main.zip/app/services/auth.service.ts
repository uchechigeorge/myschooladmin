import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Plugins } from "@capacitor/core";
import { map, tap, switchMap } from 'rxjs/operators';
import { Observable, BehaviorSubject, from } from 'rxjs';
import { loginRoute } from '../models/app-routes';
import { Router } from '@angular/router';


const { Storage } = Plugins;

export const ADMINCREDENTIALS_KEY = "credentials";
export const LOCAL_HOST = "http://localhost:58003";
export const REMOTE_HOST = "";
export const TOKEN_KEY = "token";
export const ADMINID_KEY = "adminid";
export const API_HOST = LOCAL_HOST;

const LOGIN_API_ROUTE = `${API_HOST}/api/admin/auth/login.ashx`;
const VIEWADMINAPIROUTE = `${API_HOST}/api/admin/view/viewadmin.ashx`;
const ADDADMINAPIROUTE = `${API_HOST}/api/admin/add/addadmin.ashx`;
const CONFIRMPASSWORDAPIROUTE = `${API_HOST}/api/admin/auth/confirmpassword.ashx`;
const UPDATEPASSWORDAPIROUTE = `${API_HOST}/api/admin/auth/resetpassword.ashx`;
const UPDATEADMINNAMEAPIROUTE = `${API_HOST}/api/admin/update/admin/updateusername.ashx`;
const UPDATEADMINPASSWORDAPIROUTE = `${API_HOST}/api/admin/update/admin/updatepassword.ashx`;
const UPDATEADMINROLESAPIROUTE = `${API_HOST}/api/admin/update/admin/updateroles.ashx`;

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public isAuthenticated: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(null);

  private requestToken: { adminid?: string, admintoken?: string } = {};
  public requestSubject: BehaviorSubject<{ adminid?: string, admintoken?: string }> = new BehaviorSubject<{ adminid: string, admintoken: string }>(null);

  constructor(
    private http: HttpClient,
    private router: Router,
  ) { 
    this.loadToken();
  }

  async loadToken() {
    const tokenStore = await Storage.get({ key: TOKEN_KEY });
    const adminidStore = await Storage.get({ key: ADMINID_KEY });

    const token = JSON.parse(`"${tokenStore.value}"`);
    const adminid = JSON.parse(`"${adminidStore.value}"`);

    const tokenValid = token && token != "undefined" && token != "null";
    const adminIdValid = adminid && adminid != "undefined" && adminid != "null";
    
    if(tokenValid && adminIdValid) {
      this.isAuthenticated.next(true);
      this.requestSubject.next({
        adminid,
        admintoken: token
      });
    }
    else {
      this.isAuthenticated.next(false);
      this.router.navigateByUrl(loginRoute, { replaceUrl: true });
    }
  }

  login(credentials: { username: string, password: string }): Observable<any> {
    const httpBody = JSON.stringify(credentials);
    return this.http.post(LOGIN_API_ROUTE, httpBody);
  }

  confirmPassword(credentials: { password: string }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(CONFIRMPASSWORDAPIROUTE, bodyString);
  }

  addAdmin(credentials: { username: string, password: string }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(ADDADMINAPIROUTE, bodyString);
  }

  updateAdminUsername(credentials: { adminpassword: string, admin: string, username: string }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(UPDATEADMINNAMEAPIROUTE, bodyString);
  }

  updateAdminPassword(credentials: { adminpassword: string, admin: string, password: string }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(UPDATEADMINPASSWORDAPIROUTE, bodyString);
  }

  updateRoles(credentials: { adminpassword: string, admin: string, roles: any }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(UPDATEADMINROLESAPIROUTE, bodyString);
  }

  viewAdmin(reqParams: {
    updateType?: string,
    adminid?: string,
    search?: string,
    pageSize?: string,
    pageNum?: string,
    qString?: string, 
    qStringb?: string, 
    qStringc?: string, 
  }): Observable<any>{
  let body: any = {};
  body = {...this.requestSubject.getValue()};
  const bodyString = JSON.stringify(body);
  let params: { [param: string]: string | string[]; } = {};
  
  if(reqParams.updateType) params.updatetype = reqParams.updateType; 
  if(reqParams.pageSize) params.pagesize = reqParams.pageSize;
  if(reqParams.pageNum) params.pagenum = reqParams.pageNum;
  if(reqParams.adminid) params.adminid = reqParams.adminid;
  if(reqParams.search) params.search = reqParams.search;
  if(reqParams.qString) params.qstring = reqParams.qString;
  if(reqParams.qStringb) params.qstringb = reqParams.qStringb;
  if(reqParams.qStringc) params.qstringc = reqParams.qStringc;

  return this.http.post(VIEWADMINAPIROUTE, bodyString, { params });
}


  resetPassword(credentials: { oldPassword: string, newPassword: string }): Observable<any> {
    let body: any = {};
    body = {...this.requestSubject.getValue(), ...credentials};
    const bodyString = JSON.stringify(body);
    return this.http.post(UPDATEPASSWORDAPIROUTE, bodyString);
  }

  async logout(): Promise<any> {
    this.isAuthenticated.next(false);
    Storage.remove({ key: TOKEN_KEY });
    Storage.remove({ key: ADMINID_KEY });
    Storage.remove({ key: ADMINCREDENTIALS_KEY });
  }

  async saveCredentials(credentials: { adminId?: string, token?: string, credentials?: any }) {
    if(credentials.adminId) {
      await Storage.set({ key: ADMINID_KEY, value: credentials.adminId });
      this.requestToken.adminid = credentials.adminId;
    }  
    if(credentials.token) {
      await Storage.set({ key: TOKEN_KEY, value: credentials.token });
      this.requestToken.admintoken = credentials.token;
    }
    if(credentials.credentials){
      await Storage.set({ key: ADMINCREDENTIALS_KEY, value: credentials.credentials });
    }

    this.requestSubject.next(this.requestToken);
  }
}