import { ThemePalette } from '@angular/material/core';

export interface IListDetailsOptions{
  title: string,
  id?: any,
  subtitle?: string,
  button?: boolean,
  icon?: string,
  iconSrc?: string,
  hasHeader?: boolean,
  toggle?: boolean,
  header?: string,
  showSecondaryIcon?: boolean,
  secondaryIcon?: string,
  handler?: () => void,
}

export interface IEditInput{
  id?: any,
  model: any,
  value?: string,
  type?: 'text' | 'email' | 'number' | 'password' | 'date' | 'select' | 'textarea',
  inputmode?: string,
  directives?: IInputDirectives,
  icon?: string,
  label?: string,
  maxLength?: number,
  noEdit?: boolean,
  suffix?: string,
  hasHeader?: boolean,
  headerTitle?: string,
  isValid?: boolean,
  canUpdate?: boolean,
  secondaryIcon?: string,
  secondaryText?: string,
  showSecondaryBtn?: boolean,
  valiators?: IValidatorTypes[],
  selectOptions?: ISelectOptions[] | ISelectMultipleOptions[],
  selectMultiple?: boolean,
  multipleSelectOptions?: boolean,
  updateInput?: () => Promise<boolean | void>,
  inputChange?: (e?: { event: any, model: any }) => void,
  inputBlur?: (e?: any) => void,
  secondaryBtnCLick?: (e) => void,
}

export interface ISelectOptions{
  text?: string,
  value?: string,
}

export interface ISelectMultipleOptions{
  label?: string,
  options?: ISelectOptions[],
}

export type IValidatorTypes = 'email' | 'required' | 'maxLength' | 'negative' | 'isNan' | 'currency' | 'none';
export type IInputDirectives = 'currency';

export interface CheckboxTask {
  name: string;
  completed: boolean;
  color: ThemePalette;
  subtasks?: CheckboxTask[];
}
