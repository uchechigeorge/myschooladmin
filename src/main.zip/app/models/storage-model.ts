export const themeKeyValue = 'theme';

export const asyncTimeOut = (ms: number) => new Promise<any>(resolve => setTimeout(resolve, ms));